// src/components/RetirementCalculator.js

import React, { useState, useEffect } from 'react';
import { 
  Typography, Box, Card, CardContent, 
  Tooltip, IconButton, styled, Select, MenuItem, FormControl, InputLabel, 
  TextField, InputAdornment, Tabs, Tab, Button, Dialog, DialogTitle, 
  DialogContent, DialogActions, Table, TableBody, TableCell, TableContainer, 
  TableHead, TableRow, Paper, useMediaQuery, Link
} from '@mui/material';
import Slider from '@mui/material/Slider';
import InfoIcon from '@mui/icons-material/Info';
import {  Line, XAxis, YAxis, Tooltip as ChartTooltip, ResponsiveContainer, 
   ReferenceLine, ReferenceDot, Label, Legend, ComposedChart, Bar } from 'recharts';
import { FormattedMessage, useIntl } from 'react-intl';
import { currencyOptions } from '../lib/currencyOptions';
import axios from 'axios';
import { useDebouncedCallback } from 'use-debounce';
import DeleteIcon from '@mui/icons-material/Delete';

const CustomSlider = styled(Slider)(({ theme }) => ({
  color: theme.palette.primary.main,
  height: 4,
  '& .MuiSlider-track': {
    border: 'none',
  },
  '& .MuiSlider-thumb': {
    height: 14,
    width: 14,
    backgroundColor: '#fff',
    border: '2px solid currentColor',
    '&:focus, &:hover, &.Mui-active, &.Mui-focusVisible': {
      boxShadow: 'inherit',
    },
    '&:before': {
      display: 'none',
    },
  },
  '& .MuiSlider-valueLabel': {
    lineHeight: 1.2,
    fontSize: 10,
    background: 'unset',
    padding: 0,
    width: 28,
    height: 28,
    borderRadius: '50% 50% 50% 0',
    backgroundColor: theme.palette.primary.main,
    transformOrigin: 'bottom left',
    transform: 'translate(50%, -100%) rotate(-45deg) scale(0)',
    '&:before': { display: 'none' },
    '&.MuiSlider-valueLabelOpen': {
      transform: 'translate(50%, -100%) rotate(-45deg) scale(1)',
    },
    '& > *': {
      transform: 'rotate(45deg)',
    },
  },
}));

const SliderComponent = ({ label, value, onChange, onChangeCommitted, min, max, step = 1, tooltipText, formatValue, allowInput = false, currency, sx }) => {
  const [inputValue, setInputValue] = useState(value.toString());
  const currencySymbol = currencyOptions.find(option => option.value === currency)?.symbol || '$';

  const handleSliderChange = (event, newValue) => {
    onChange(event, newValue);
    setInputValue(newValue.toString());
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleInputBlur = () => {
    const newValue = Number(inputValue);
    if (!isNaN(newValue) && newValue >= min && newValue <= max) {
      onChange(null, newValue);
      onChangeCommitted(null, newValue);
    } else {
      setInputValue(value.toString());
    }
  };

  return (
    <Box sx={{ marginBottom: 2.5, ...sx }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 0.5 }}>
        <Typography variant="caption">
          {label}
          {tooltipText && (
            <Tooltip title={tooltipText}>
              <IconButton size="small" sx={{ padding: 0, marginLeft: 0.5 }}>
                <InfoIcon fontSize="inherit" />
              </IconButton>
            </Tooltip>
          )}
        </Typography>
        {allowInput ? (
          <TextField
            value={inputValue}
            onChange={handleInputChange}
            onBlur={handleInputBlur}
            size="small"
            sx={{ width: '100px' }}
            InputProps={{
              startAdornment: <InputAdornment position="start">{currencySymbol}</InputAdornment>,
            }}
          />
        ) : (
          <Typography variant="caption" color="text.secondary">
            {formatValue(value)}
          </Typography>
        )}
      </Box>
      <CustomSlider
        size="small"
        value={typeof value === 'number' ? value : 0}
        onChange={handleSliderChange}
        onChangeCommitted={onChangeCommitted}
        valueLabelDisplay="auto"
        min={min}
        max={max}
        step={step}
      />
    </Box>
  );
};

const PanelComponent = ({ title, value, description, color, isNumber = false, formatValue }) => (
  <Card sx={{ flexGrow: 1 }}>
    <CardContent sx={{ textAlign: 'center' }}>
      <Typography variant="h6" color={color}>
        {isNumber 
          ? Math.abs(Math.round(value)).toLocaleString()
          : formatValue(Math.abs(value))}
      </Typography>
      <Typography variant="body2">{title}</Typography>
      <Typography variant="caption">{description}</Typography>
    </CardContent>
  </Card>
);

const formatYAxis = (value) => {
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}m`;
  } else if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}k`;
  }
  return value;
};

const GraphComponent = ({ data, currentAge, ageOfRetirement, ageOfDeath, formatCurrency, oneOffExpenses, peakCorpus, peakCorpusAge }) => {
  const generateTicks = () => {
    let ticks = [currentAge, ageOfRetirement, ageOfDeath];
    oneOffExpenses.forEach(expense => {
      if (!ticks.includes(expense.age)) {
        ticks.push(expense.age);
      }
    });
    return ticks.sort((a, b) => a - b);
  };

  return (
    <ResponsiveContainer width="100%" height={350}>
      <ComposedChart 
        data={data} 
        margin={{ top: 20, right: 30, left: 0, bottom: 30 }}
      >
        <XAxis 
          dataKey="year" 
          tick={{ fontFamily: 'Roboto', fontSize: 12 }}
          tickLine={false}
          ticks={generateTicks()}
          padding={{ left: 0, right: 0 }}
          axisLine={{ strokeWidth: 1 }}
        />
        <YAxis 
          tick={{ fontFamily: 'Roboto', fontSize: 12 }}
          tickFormatter={(value) => formatCurrency(value)}
          axisLine={false}
          tickLine={false}
        />
        <ChartTooltip 
          formatter={(value) => formatCurrency(value)}
          contentStyle={{ fontFamily: 'Roboto', fontSize: 12 }}
        />
        <Legend 
          verticalAlign="bottom"
          align="center"
          wrapperStyle={{
            fontFamily: 'Roboto',
            fontSize: 12,
            paddingTop: 10,
            position: 'relative',
            marginTop: '-25px',
          }}
          iconSize={12}
          iconType="circle"
        />
        <Bar dataKey="oneOffExpense" fill="#ff6b6b" name="One-off Expense" />
        <Bar dataKey="removedExpense" fill="#4ecdc4" name="Removed Expense" />
        <Line type="monotone" dataKey="totalCorpus" stroke="#0D5D56" strokeWidth={2} dot={false} name="Total Corpus" />
        <Line type="monotone" dataKey="annualExpenses" stroke="#dc004e" strokeWidth={2} dot={false} name="Annual Expenses" />
        
        <ReferenceLine
          x={peakCorpusAge}
          stroke="#0D5D56"
          strokeWidth={1.5}
          strokeDasharray="5 5"
          label={{
            value: `Peak: ${formatCurrency(peakCorpus)}`,
            position: 'top',
            fill: '#0D5D56',
            fontSize: 14,
            fontFamily: 'Roboto',
          }}
        />
        
        <ReferenceDot
          x={peakCorpusAge}
          y={peakCorpus}
          r={5}
          fill="#0D5D56"
          stroke="#FFFFFF"
          strokeWidth={1.5}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
};

export default function RetirementCalculator() {
  const intl = useIntl();
  const [currentAge, setCurrentAge] = useState(30);
  const [annualExpenses, setAnnualExpenses] = useState(50000);
  const [ageOfRetirement, setAgeOfRetirement] = useState(65);
  const [ageOfDeath, setAgeOfDeath] = useState(85);
  const [estimatedInflationRate, setEstimatedInflationRate] = useState(2);
  const [annualInvestment, setAnnualInvestment] = useState(10000);
  const [returnOnInvestment, setReturnOnInvestment] = useState(7);
  const [currentInvestmentValue, setCurrentInvestmentValue] = useState(0);

  const [surplusCash, setSurplusCash] = useState(0);
  const [additionalYears, setAdditionalYears] = useState(0);
  const [peakCorpus, setPeakCorpus] = useState(0);
  const [peakCorpusAge, setPeakCorpusAge] = useState(0);
  const [isOnTrack, setIsOnTrack] = useState(true);
  const [graphData, setGraphData] = useState([]);

  const [currency, setCurrency] = useState('GBP');
  const [locale, setLocale] = useState('en-GB');
  const [language, setLanguage] = useState('en');
  const [userIpAddress, setUserIpAddress] = useState('');

  const [activeTab, setActiveTab] = useState(0);
  const [oneOffExpenses, setOneOffExpenses] = useState([]);
  const [openExpenseDialog, setOpenExpenseDialog] = useState(false);
  const [newExpense, setNewExpense] = useState({ age: currentAge, amount: '', category: '', type: 'oneOff' });

  const [incomes, setIncomes] = useState([]);
  const [openIncomeDialog, setOpenIncomeDialog] = useState(false);
  const [newIncome, setNewIncome] = useState({
    age: ageOfRetirement,
    amount: '',
    incrementRate: 0,
    type: 'pension',
    subtype: ''
  });

  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));

  useEffect(() => {
    const detectLocale = () => {
      const userLocale = navigator.language || 'en-GB';
      setLocale(userLocale);

      const currencyMap = {
        'en-US': 'USD',
        'en-GB': 'GBP',
        'de-DE': 'EUR',
        'ja-JP': 'JPY',
        'es-ES': 'EUR',
        'fr-FR': 'EUR',
        'hi-IN': 'INR',
      };

      setCurrency(currencyMap[userLocale] || 'GBP');

      const languageMap = {
        'en': 'en',
        'es': 'es',
        'fr': 'fr',
        'de': 'de',
        'hi': 'hi',
      };
      setLanguage(languageMap[userLocale.split('-')[0]] || 'en');
    };

    detectLocale();
  }, []);

  useEffect(() => {
    const fetchIpAddress = async () => {
      try {
        const response = await axios.get('https://api.ipify.org?format=json');
        setUserIpAddress(response.data.ip);
      } catch (error) {
        console.error('Error fetching IP address:', error);
      }
    };

    fetchIpAddress();
  }, []);

  useEffect(() => {
    calculateRetirement();
  }, []);

  const formatCurrency = (value) => {
    if (currency === 'INR') {
      if (value >= 10000000) {
        const crore = value / 10000000;
        return `₹${crore.toFixed(2)} Cr`;
      } else if (value >= 100000) {
        const lakh = value / 100000;
        return `₹${lakh.toFixed(2)} L`;
      }
    }
    
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency,
      notation: 'compact',
      compactDisplay: 'short',
    }).format(value);
  };

  const calculateRetirement = (expenses = oneOffExpenses, incomeSources = incomes) => {
    // Your existing calculation logic
  };

  const handleSliderChange = (setter) => (_, newValue) => {
    setter(newValue);
  };

  const handleSliderChangeCommitted = (setter) => (_, newValue) => {
    setter(newValue);
    debouncedSaveCalculation();
  };

  const saveCalculation = async () => {
    try {
      const response = await fetch('/api/save-calculation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          currentAge,
          annualExpenses,
          ageOfRetirement,
          ageOfDeath,
          estimatedInflationRate,
          annualInvestment,
          returnOnInvestment,
          currentInvestmentValue,
          surplusCash,
          additionalYears,
          peakCorpus,
          peakCorpusAge,
          isOnTrack,
          currency,
          locale,
          language,
          ipAddress: userIpAddress,
        }),
      });
      const data = await response.json();
      console.log('Calculation saved:', data);
    } catch (error) {
      console.error('Error saving calculation:', error);
    }
  };

  const debouncedSaveCalculation = useDebouncedCallback(
    () => {
      calculateRetirement();
      saveCalculation();
    },
    500
  );

  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
    if (newLanguage === 'hi') {
      setLocale('hi-IN');
      setCurrency('INR');
    } else {
      setLocale(newLanguage + '-' + newLanguage.toUpperCase());
      setCurrency(currency || 'USD');
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleAddExpense = () => {
    if (newExpense.age && parseFloat(newExpense.amount) > 0 && newExpense.category && newExpense.type) {
      setOneOffExpenses(prevExpenses => {
        const updatedExpenses = [...prevExpenses, {
          ...newExpense,
          amount: parseFloat(newExpense.amount)
        }];
        calculateRetirement(updatedExpenses);
        return updatedExpenses;
      });
      setOpenExpenseDialog(false);
      setNewExpense({ age: currentAge, amount: '', category: '', type: 'oneOff' });
    } else {
      alert('Please fill in all fields and ensure the amount is greater than 0.');
    }
  };

  const handleDeleteExpense = (index) => {
    setOneOffExpenses(prevExpenses => {
      const updatedExpenses = prevExpenses.filter((_, i) => i !== index);
      calculateRetirement(updatedExpenses);
      return updatedExpenses;
    });
  };

  const handleOpenIncomeDialog = () => {
    setNewIncome(prevState => ({
      ...prevState,
      age: ageOfRetirement
    }));
    setOpenIncomeDialog(true);
  };

  const handleAddIncome = () => {
    if (newIncome.age && parseFloat(newIncome.amount) > 0 && newIncome.subtype && newIncome.type) {
      setIncomes(prevIncomes => {
        const updatedIncomes = [...prevIncomes, {
          ...newIncome,
          amount: parseFloat(newIncome.amount)
        }];
        calculateRetirement(undefined, updatedIncomes);
        return updatedIncomes;
      });
      setOpenIncomeDialog(false);
      setNewIncome({ age: ageOfRetirement, amount: '', incrementRate: 0, type: 'pension', subtype: '' });
    } else {
      alert('Please fill in all fields and ensure the amount is greater than 0.');
    }
  };

  const handleDeleteIncome = (index) => {
    setIncomes(prevIncomes => {
      const updatedIncomes = prevIncomes.filter((_, i) => i !== index);
      calculateRetirement(undefined, updatedIncomes);
      return updatedIncomes;
    });
  };

  return (
    <Box sx={{ maxWidth: 1200, margin: 'auto', padding: 2, backgroundColor: 'background.default', position: 'relative' }}>
      <Box sx={{ 
        position: 'absolute',
        top: 8,
        right: 16,
        zIndex: 1,
        display: 'flex',
        alignItems: 'center',
        gap: 2
      }}>
        <Link
          href="https://blog.retireseed.com"
          target="_blank"
          rel="noopener noreferrer"
          sx={{
            color: 'primary.main',
            textDecoration: 'none',
            fontSize: '12px',
            fontFamily: 'Roboto, sans-serif',
            '&:hover': {
              textDecoration: 'underline',
            },
          }}
        >
          <FormattedMessage id="blog" />
        </Link>
        <FormControl size="small" sx={{ minWidth: 80 }}>
          <Select
            value={language}
            onChange={(e) => handleLanguageChange(e.target.value)}
            displayEmpty
            inputProps={{ 'aria-label': 'Select language' }}
            sx={{ fontSize: '12px', height: '28px' }}
          >
            <MenuItem value="en" sx={{ fontSize: '12px' }}>EN</MenuItem>
            <MenuItem value="es" sx={{ fontSize: '12px' }}>ES</MenuItem>
            <MenuItem value="fr" sx={{ fontSize: '12px' }}>FR</MenuItem>
            <MenuItem value="de" sx={{ fontSize: '12px' }}>DE</MenuItem>
            <MenuItem value="hi" sx={{ fontSize: '12px' }}>HI</MenuItem>
          </Select>
        </FormControl>
      </Box>

      <Box sx={{ 
        textAlign: 'center',
        marginTop: 4,
        marginBottom: 2
      }}>
        <Typography variant="h4" color="primary" sx={{ 
          fontSize: { xs: '1.5rem', sm: '2rem' },
        }}>
          <FormattedMessage id="title" />
        </Typography>
      </Box>

      <Typography variant="body2" align="center" gutterBottom color="text.secondary">
        <FormattedMessage id="description" />
      </Typography>

      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, marginTop: 2 }}>
        <Card sx={{ flexBasis: '300px', flexGrow: 1 }}>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography variant="caption" sx={{ marginRight: 1 }}>Currency:</Typography>
                <FormControl size="small" sx={{ minWidth: 60 }}>
                  <Select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    displayEmpty
                    inputProps={{ 'aria-label': 'Select currency' }}
                    sx={{ fontSize: '0.75rem', padding: '2px 8px' }}
                  >
                    {currencyOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value} sx={{ fontSize: '0.75rem' }}>
                        {option.symbol}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Box>
          
            <Tabs 
              value={activeTab} 
              onChange={handleTabChange} 
              aria-label="retirement calculator tabs"
              sx={{ marginBottom: 2 }}
              variant={isMobile ? "scrollable" : "standard"}
              scrollButtons={isMobile ? "auto" : false}
              allowScrollButtonsMobile
            >
              <Tab label={<FormattedMessage id="basicInfo" />} />
              <Tab label={<FormattedMessage id="expenses" />} />
              <Tab label={<FormattedMessage id="investments" />} />
              <Tab label={<FormattedMessage id="income" />} />
            </Tabs>

            <Box sx={{ marginTop: 2 }}>
              {activeTab === 0 && (
                <>
                  <SliderComponent
                    label={<FormattedMessage id="currentAge" />}
                    value={currentAge}
                    onChange={handleSliderChange(setCurrentAge)}
                    onChangeCommitted={handleSliderChangeCommitted(setCurrentAge)}
                    min={1}
                    max={120}
                    tooltipText={<FormattedMessage id="currentAgeTooltip" />}
                    formatValue={(value) => value.toLocaleString()}
                  />
                  <SliderComponent
                    label={<FormattedMessage id="ageOfRetirement" />}
                    value={ageOfRetirement}
                    onChange={handleSliderChange(setAgeOfRetirement)}
                    onChangeCommitted={handleSliderChangeCommitted(setAgeOfRetirement)}
                    min={1}
                    max={120}
                    tooltipText={<FormattedMessage id="ageOfRetirementTooltip" />}
                    formatValue={(value) => value.toLocaleString()}
                  />
                  <SliderComponent
                    label={<FormattedMessage id="ageOfDeath" />}
                    value={ageOfDeath}
                    onChange={handleSliderChange(setAgeOfDeath)}
                    onChangeCommitted={handleSliderChangeCommitted(setAgeOfDeath)}
                    min={1}
                    max={120}
                    tooltipText={<FormattedMessage id="ageOfDeathTooltip" />}
                    formatValue={(value) => value.toLocaleString()}
                  />
                </>
              )}

              {activeTab === 1 && (
                <>
                  <SliderComponent
                    label={<FormattedMessage id="annualExpenses" />}
                    value={annualExpenses}
                    onChange={handleSliderChange(setAnnualExpenses)}
                    onChangeCommitted={handleSliderChangeCommitted(setAnnualExpenses)}
                    min={0}
                    max={10000000}
                    step={1000}
                    tooltipText={<FormattedMessage id="annualExpensesTooltip" />}
                    formatValue={formatCurrency}
                    allowInput={true}
                    currency={currency}
                  />
                  <SliderComponent
                    label={<FormattedMessage id="estimatedInflationRate" />}
                    value={estimatedInflationRate}
                    onChange={handleSliderChange(setEstimatedInflationRate)}
                    onChangeCommitted={handleSliderChangeCommitted(setEstimatedInflationRate)}
                    min={1}
                    max={20}
                    step={0.1}
                    tooltipText={<FormattedMessage id="estimatedInflationRateTooltip" />}
                    formatValue={(value) => `${value.toFixed(1)}%`}
                  />
                  <Box sx={{ marginTop: 2 }}>
                    <Button variant="outlined" onClick={() => setOpenExpenseDialog(true)} size="small">
                      <FormattedMessage id="manageExpenses" />
                    </Button>
                    <TableContainer component={Paper} sx={{ marginTop: 2, maxWidth: '100%' }}>
                      <Table size="small" aria-label="manage expenses table">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="age" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="amount" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="category" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="type" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="actions" /></TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {oneOffExpenses.map((expense, index) => (
                            <TableRow key={index}>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{expense.age}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{formatCurrency(parseFloat(expense.amount))}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{expense.category}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>
                                <FormattedMessage 
                                  id={expense.type === 'oneOff' ? 'Add' : 'Remove'} 
                                />
                              </TableCell>
                              <TableCell sx={{ padding: '6px 8px' }}>
                                <IconButton onClick={() => handleDeleteExpense(index)} size="small">
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Box>
                </>
              )}

              {activeTab === 2 && (
                <>
                  <SliderComponent
                    label={<FormattedMessage id="currentInvestmentValue" />}
                    value={currentInvestmentValue}
                    onChange={handleSliderChange(setCurrentInvestmentValue)}
                    onChangeCommitted={handleSliderChangeCommitted(setCurrentInvestmentValue)}
                    min={0}
                    max={100000000}
                    step={1000}
                    tooltipText={<FormattedMessage id="currentInvestmentValueTooltip" />}
                    formatValue={formatCurrency}
                    allowInput={true}
                    currency={currency}
                  />
                  <SliderComponent
                    label={<FormattedMessage id="annualInvestmentUntilRetirement" />}
                    value={annualInvestment}
                    onChange={handleSliderChange(setAnnualInvestment)}
                    onChangeCommitted={handleSliderChangeCommitted(setAnnualInvestment)}
                    min={0}
                    max={1000000}
                    step={1000}
                    tooltipText={<FormattedMessage id="annualInvestmentUntilRetirementTooltip" />}
                    formatValue={formatCurrency}
                    allowInput={true}
                    currency={currency}
                  />
                  <SliderComponent
                    label={<FormattedMessage id="returnOnInvestment" />}
                    value={returnOnInvestment}
                    onChange={handleSliderChange(setReturnOnInvestment)}
                    onChangeCommitted={handleSliderChangeCommitted(setReturnOnInvestment)}
                    min={1}
                    max={30}
                    step={0.1}
                    tooltipText={<FormattedMessage id="returnOnInvestmentTooltip" />}
                    formatValue={(value) => `${value.toFixed(1)}%`}
                  />
                </>
              )}

              {activeTab === 3 && (
                <>
                  <Box sx={{ marginTop: 2 }}>
                    <Button variant="outlined" onClick={handleOpenIncomeDialog} size="small">
                      <FormattedMessage id="addRetirementIncome" />
                    </Button>
                    <TableContainer component={Paper} sx={{ marginTop: 2, maxWidth: '100%' }}>
                      <Table size="small" aria-label="manage incomes table">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="age" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="amount" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="category" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}><FormattedMessage id="incomeIncrementRate" /></TableCell>
                            <TableCell sx={{ padding: '6px 8px', fontSize: '75rem' }}><FormattedMessage id="actions" /></TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {incomes.map((income, index) => (
                            <TableRow key={index}>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{income.age}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{formatCurrency(parseFloat(income.amount))}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{income.subtype}</TableCell>
                              <TableCell sx={{ padding: '6px 8px', fontSize: '0.75rem' }}>{`${income.incrementRate}%`}</TableCell>
                              <TableCell sx={{ padding: '6px 8px' }}>
                                <IconButton onClick={() => handleDeleteIncome(index)} size="small">
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Box>
                </>
              )}
            </Box>
          </CardContent>
        </Card>

        <Box sx={{ flexBasis: '600px', flexGrow: 2 }}>
          <Box sx={{ display: 'flex', gap: 2, marginBottom: 2 }}>
            <PanelComponent
              title={
                <FormattedMessage 
                  id={isOnTrack ? "monthlyInvestmentUntilRetirement" : "insufficientMonthlyInvestment"}
                />
              }
              value={Math.round(annualInvestment / 12)}
              description=""
              color={isOnTrack ? "primary.main" : "error.main"}
              formatValue={formatCurrency}
            />
            <PanelComponent
              title={<FormattedMessage id={isOnTrack ? "surplusBeyondLifeExpectancy" : "corpusShortfall"} />}
              value={Math.abs(surplusCash)}
              description=""
              color={isOnTrack ? "success.main" : "error.main"}
              formatValue={formatCurrency}
            />
            <PanelComponent
              title={<FormattedMessage id={isOnTrack ? "extraYearsCorpusWillLast" : "yearsShortOnCorpus"} />}
              value={Math.abs(additionalYears)}
              description=""
              color={isOnTrack ? "success.main" : "error.main"}
              isNumber={true}
              formatValue={(value) => value.toLocaleString()}
            />
          </Box>

          <Card sx={{ marginBottom: 2 }}>
            <CardContent>
              <Typography variant="body1" color={isOnTrack ? "success.main" : "error.main"} align="center">
                <FormattedMessage id={isOnTrack ? "onTrackMessage" : "notOnTrackMessage"} />
              </Typography>
            </CardContent>
          </Card>

          <Card sx={{ flexGrow: 1 }}>
            <CardContent>
              <Typography variant="body2" gutterBottom color="primary" align="center">
                <FormattedMessage id="corpusGrowthDecline" />
              </Typography>
              {graphData.length > 0 && (
                <GraphComponent 
                  data={graphData} 
                  currentAge={currentAge}
                  ageOfRetirement={ageOfRetirement}
                  ageOfDeath={ageOfDeath}
                  formatCurrency={formatCurrency}
                  oneOffExpenses={oneOffExpenses}
                  peakCorpus={peakCorpus}
                  peakCorpusAge={peakCorpusAge}
                />
              )}
            </CardContent>
          </Card>

          <Card sx={{ marginTop: 2 }}>
            <CardContent sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Typography variant="body2" fontSize={12} color="text.secondary" align="center">
                <FormattedMessage id="contactMessage" />
              </Typography>
            </CardContent>
          </Card>
        </Box>
      </Box>

      <Box sx={{ marginTop: 4 }}>
        <Typography variant="h5" color="primary" gutterBottom>
          <FormattedMessage id="whyRetirementPlanningIsEssential" />
        </Typography>
        <Typography variant="body2" paragraph>
          <FormattedMessage id="whyRetirementPlanningIsEssentialContent" />
        </Typography>

        <Typography variant="h5" color="primary" gutterBottom>
          <FormattedMessage id="roleOfAccurateForecasting" />
        </Typography>
        <Typography variant="body2" paragraph>
          <FormattedMessage id="roleOfAccurateForecastingContent" />
        </Typography>

        <Typography variant="h5" color="primary" gutterBottom>
          <FormattedMessage id="introducingTheApp" />
        </Typography>
        <Typography variant="body2" paragraph>
          <FormattedMessage id="introducingTheAppContent" />
        </Typography>

        <Typography variant="h5" color="primary" gutterBottom>
          <FormattedMessage id="identifyingShortfalls" />
        </Typography>
        <Typography variant="body2" paragraph>
          <FormattedMessage id="identifyingShortfallsContent" />
        </Typography>

        <Typography variant="h5" color="primary" gutterBottom>
          <FormattedMessage id="planningForSecureFuture" />
        </Typography>
        <Typography variant="body2" paragraph>
          <FormattedMessage id="planningForSecureFutureContent" />
        </Typography>
      </Box>

      <Dialog open={openExpenseDialog} onClose={() => setOpenExpenseDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle><FormattedMessage id="manageExpenses" /></DialogTitle>
        <DialogContent>
          <Typography variant="caption" sx={{ display: 'block', mb: 2 }}>
            <FormattedMessage id="manageExpensesDescription" />
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <SliderComponent
              label={<FormattedMessage id="age" />}
              value={newExpense.age}
              onChange={(_, newValue) => {
                if (newValue >= currentAge && newValue <= ageOfDeath) {
                  setNewExpense({...newExpense, age: newValue});
                }
              }}
              min={currentAge}
              max={ageOfDeath}
              step={1}
              marks
              valueLabelDisplay="on"
              formatValue={(value) => value.toLocaleString()}
              sx={{ width: '100%', mb: 1 }}
            />

            <SliderComponent
              label={<FormattedMessage id="expenseAmount" />}
              value={parseFloat(newExpense.amount) || 0}
              onChange={(_, newValue) => setNewExpense({...newExpense, amount: newValue.toString()})}
              onChangeCommitted={(_, newValue) => setNewExpense({...newExpense, amount: newValue.toString()})}
              min={0}
              max={1000000}
              step={1000}
              formatValue={formatCurrency}
              allowInput={true}
              currency={currency}
              sx={{ width: '100%', mb: 1 }}
            />

            <FormControl fullWidth size="small" sx={{ mt: 1 }}>
              <InputLabel id="expense-type-label">
                <FormattedMessage id="expenseType" />
              </InputLabel>
              <Select
                labelId="expense-type-label"
                value={newExpense.type}
                onChange={(e) => setNewExpense({...newExpense, type: e.target.value})}
                label={<FormattedMessage id="expenseType" />}
              >
                <MenuItem value="oneOff"><FormattedMessage id="Add" /></MenuItem>
                <MenuItem value="recurring"><FormattedMessage id="Remove" /></MenuItem>
              </Select>
            </FormControl>

            <FormControl fullWidth size="small" sx={{ mt: 1 }}>
              <InputLabel id="expense-category-label">
                <FormattedMessage id="expenseCategory" />
              </InputLabel>
              <Select
                labelId="expense-category-label"
                value={newExpense.category}
                onChange={(e) => setNewExpense({...newExpense, category: e.target.value})}
                label={<FormattedMessage id="expenseCategory" />}
              >
                <MenuItem value="Wedding"><FormattedMessage id="wedding" /></MenuItem>
                <MenuItem value="Education"><FormattedMessage id="education" /></MenuItem>
                <MenuItem value="Travel"><FormattedMessage id="travel" /></MenuItem>
                <MenuItem value="Mortgage"><FormattedMessage id="mortgage" /></MenuItem>
                <MenuItem value="Other"><FormattedMessage id="other" /></MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenExpenseDialog(false)}><FormattedMessage id="cancel" /></Button>
          <Button onClick={handleAddExpense}><FormattedMessage id="add" /></Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openIncomeDialog} onClose={() => setOpenIncomeDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle><FormattedMessage id="addRetirementIncome" /></DialogTitle>
        <DialogContent>
          <Typography variant="caption" sx={{ display: 'block', mb: 2 }}>
            <FormattedMessage id="addRetirementIncomeDescription" />
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <SliderComponent
              label={<FormattedMessage id="age" />}
              value={newIncome.age}
              onChange={(_, newValue) => {
                if (newValue >= ageOfRetirement && newValue <= ageOfDeath) {
                  setNewIncome({...newIncome, age: newValue});
                }
              }}
              min={ageOfRetirement}
              max={ageOfDeath}
              step={1}
              marks
              valueLabelDisplay="on"
              formatValue={(value) => value.toLocaleString()}
              sx={{ width: '100%', mb: 1 }}
            />

            <SliderComponent
              label={<FormattedMessage id="incomeAmount" />}
              value={parseFloat(newIncome.amount) || 0}
              onChange={(_, newValue) => setNewIncome({...newIncome, amount: newValue.toString()})}
              onChangeCommitted={(_, newValue) => setNewIncome({...newIncome, amount: newValue.toString()})}
              min={0}
              max={1000000}
              step={1000}
              formatValue={formatCurrency}
              allowInput={true}
              currency={currency}
              sx={{ width: '100%', mb: 1 }}
            />

            <SliderComponent
              label={<FormattedMessage id="incomeIncrementRate" />}
              value={newIncome.incrementRate}
              onChange={(_, newValue) => setNewIncome({...newIncome, incrementRate: newValue})}
              min={0}
              max={30}
              step={0.1}
              formatValue={(value) => `${value}%`}
              sx={{ width: '100%', mb: 1 }}
            />

            <FormControl fullWidth size="small" sx={{ mt: 1 }}>
              <InputLabel id="income-type-label">
                <FormattedMessage id="incomeType" />
              </InputLabel>
              <Select
                labelId="income-type-label"
                value={newIncome.type}
                onChange={(e) => setNewIncome({...newIncome, type: e.target.value})}
                label={<FormattedMessage id="incomeType" />}
              >
                <MenuItem value="pension"><FormattedMessage id="pension" /></MenuItem>
                <MenuItem value="passive"><FormattedMessage id="passive" /></MenuItem>
              </Select>
            </FormControl>

            <FormControl fullWidth size="small" sx={{ mt: 1 }}>
              <InputLabel id="income-subtype-label">
                <FormattedMessage id="incomeSubtype" />
              </InputLabel>
              <Select
                labelId="income-subtype-label"
                value={newIncome.subtype}
                onChange={(e) => setNewIncome({...newIncome, subtype: e.target.value})}
                label={<FormattedMessage id="incomeSubtype" />}
              >
                <MenuItem value="Rental"><FormattedMessage id="rental" /></MenuItem>
                <MenuItem value="Dividends"><FormattedMessage id="dividends" /></MenuItem>
                <MenuItem value="Pension"><FormattedMessage id="pension" /></MenuItem>
                <MenuItem value="Other"><FormattedMessage id="other" /></MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenIncomeDialog(false)}><FormattedMessage id="cancel" /></Button>
          <Button onClick={handleAddIncome}><FormattedMessage id="add" /></Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}