import React from 'react';
import Head from 'next/head';

function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <title>Retirement Calculator | Plan Your Financial Future</title>
        <meta name="description" content="Use our advanced retirement calculator to plan your financial future. Understand your investment needs and secure your retirement with ease." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}

export default MyApp;