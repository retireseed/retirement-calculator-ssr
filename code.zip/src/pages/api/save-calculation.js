import { openDb } from '../../lib/db';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    try {
      const db = await openDb();
      const {
        currentAge,
        annualExpenses,
        ageOfRetirement,
        ageOfDeath,
        estimatedInflationRate,
        annualInvestment,
        returnOnInvestment,
        currentInvestmentValue,
        surplusCash,
        additionalYears,
        peakCorpus,
        peakCorpusAge,
        isOnTrack,
        currency,
        locale,
        language,
        ipAddress
      } = req.body;

      const ip_address = ipAddress || req.headers['x-forwarded-for'] || req.socket.remoteAddress;

      const result = await db.run(`INSERT INTO calculations (
        ip_address, current_age, annual_expenses, age_of_retirement, age_of_death,
        estimated_inflation_rate, annual_investment, return_on_investment,
        current_investment_value, surplus_cash, additional_years, peak_corpus,
        peak_corpus_age, is_on_track, currency, locale, language
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          ip_address, currentAge, annualExpenses, ageOfRetirement, ageOfDeath,
          estimatedInflationRate, annualInvestment, returnOnInvestment,
          currentInvestmentValue, surplusCash, additionalYears, peakCorpus,
          peakCorpusAge, isOnTrack ? 1 : 0, currency, locale, language
        ]
      );

      console.log('Calculation saved with ID:', result.lastID);
      res.status(200).json({ message: 'Calculation saved successfully', id: result.lastID });
    } catch (error) {
      console.error('Error saving calculation:', error);
      res.status(500).json({ error: 'Error saving calculation' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}