import React from 'react';
import dynamic from 'next/dynamic';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { IntlProvider } from 'react-intl';
import translations from '../lib/translations';
import theme from '../lib/theme'; // You'll need to create this

const RetirementCalculator = dynamic(() => import('../components/RetirementCalculator'), {
  ssr: false
});

export default function Home() {
  const [language, setLanguage] = React.useState('en');

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <IntlProvider messages={translations[language]} locale={language} defaultLocale="en">
        <RetirementCalculator />
      </IntlProvider>
    </ThemeProvider>
  );
}